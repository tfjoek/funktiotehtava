var x = myFunction(5, 5);
document.getElementById("happi").innerHTML = x;

function myFunction(a, b) {
  return a * b;
}